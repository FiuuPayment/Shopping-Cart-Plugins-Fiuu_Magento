<?php
/**
 * Fiuu
 *
 * @package     Fiuu Magento Plugin
 * @author      netbuilder <code@netbuilder.com.my>
 * @copyright   Copyright (c) 2012 - 2014, Fiuu
 * @link        http://fiuu.com
 * @since       Version 1.8.x.x
 * @update      Fiuu <technical@fiuu.com>
 * @filesource  https://github.com/FiuuPayment/Shopping-Cart-Plugins-Fiuu_Magento
 */

class Mage_MOLPay_Model_PaymentMethod_Source_Encrytype {
    public function toOptionArray() {
        return array(
            array(
                'value' => "md5",
                'label' => Mage::helper('molpay')->__('MD5')
            ),
            array(
                'value' => "sha1",
                'label' => Mage::helper('molpay')->__('SHA1')
            )
        );
    }
}